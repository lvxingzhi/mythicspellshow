--- MythicTips: 大秘境怪物机制提示插件
--- 目标切换敌对NPC时弹出暗色系UI框显示技能和自定义心得
--- @author ext.ahs.lvxingz1

local AddonName, MT = ...
_G["MT"] = MT

local LibStub = LibStub

--- 本地化引用常用全局函数
local CreateFrame, tonumber, select, strsplit, pairs, ipairs, wipe =
    CreateFrame, tonumber, select, strsplit, pairs, ipairs, wipe
local UnitGUID, UnitName, UnitCanAttack =
    UnitGUID, UnitName, UnitCanAttack
local GetSpellName, GetSpellDescription, GetSpellTexture =
    C_Spell.GetSpellName, C_Spell.GetSpellDescription, C_Spell.GetSpellTexture
local RequestLoadSpellData = C_Spell.RequestLoadSpellData

local db
local mainFrame
--- 技能信息缓存表，进入大秘境时按当前副本懒加载
local spellCache = {}
--- 是否在大秘境中运行
local inMythicPlus = false
--- 上一次显示的npcID，用于跳过相同目标的重复刷新
local lastNpcID

-------------------------
--- 默认配置        ----
-------------------------
local defaults = {
  profile = {
    enabled = true,
    showInCombat = true,
    showSpellDesc = true,
    showCustomTips = true,
    showDefaultTips = true,
    position = {
      point = "CENTER",
      relPoint = "CENTER",
      x = 0,
      y = 0,
    },
    customTips = {},
    defaultTips = {},
    display = {
      scale = 1.0,
      alpha = 0.9,
    },
  },
}

-------------------------
--- 斜杠命令        ----
-------------------------
SLASH_MythicTips1 = "/mt"
SLASH_MythicTips2 = "/mythictips"

--- 斜杠命令处理函数
--- @param cmd string 命令参数
function SlashCmdList.MythicTips(cmd, editbox)
  cmd = cmd and cmd:lower() or ""
  if cmd == "reset" then
    if mainFrame then
      mainFrame:ClearAllPoints()
      mainFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
      MT:SavePosition()
    end
  elseif cmd == "config" or cmd == "options" then
    MT:OpenConfig()
  else
    MT:ToggleFrame()
  end
end

-------------------------
--- 初始化          ----
-------------------------
local eventFrame
eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:RegisterEvent("CHALLENGE_MODE_START")
eventFrame:RegisterEvent("CHALLENGE_MODE_COMPLETED")

--- 事件分发处理
eventFrame:SetScript("OnEvent", function(self, event, ...)
  if event == "ADDON_LOADED" then
    local addon = ...
    if addon == "MythicTips" then
      MT:OnInitialize()
      self:UnregisterEvent("ADDON_LOADED")
    end
  elseif event == "CHALLENGE_MODE_START" then
    MT:OnEnterMythicPlus()
  elseif event == "CHALLENGE_MODE_COMPLETED" then
    MT:OnLeaveMythicPlus()
  elseif event == "PLAYER_TARGET_CHANGED" then
    MT:OnTargetChanged()
  end
end)

--- 插件初始化，ADDON_LOADED时调用，不预加载缓存，不注册目标事件
function MT:OnInitialize()
  local AceDB = LibStub("AceDB-3.0")
  db = AceDB:New("MythicTipsDB", defaults, true)
  MT.db = db

  -- 注册配置面板
  MT:RegisterConfig()

  -- 创建主显示框（隐藏状态）
  MT:CreateMainFrame()

  -- 不在这里注册PLAYER_TARGET_CHANGED，等进入大秘境再注册
  print("|cFF00FF00MythicTips|r loaded. Type /mt for help.")
end

--- 进入大秘境时激活插件
function MT:OnEnterMythicPlus()
  if inMythicPlus then return end
  inMythicPlus = true

  -- 按当前副本懒加载技能缓存（只加载当前副本的NPC技能）
  MT:PreloadSpellCacheForCurrentDungeon()

  -- 仅在大秘境中注册目标切换事件
  eventFrame:RegisterEvent("PLAYER_TARGET_CHANGED")
end

--- 离开大秘境时停用插件
function MT:OnLeaveMythicPlus()
  if not inMythicPlus then return end
  inMythicPlus = false
  lastNpcID = nil

  -- 注销目标切换事件，停止一切运行时开销
  eventFrame:UnregisterEvent("PLAYER_TARGET_CHANGED")

  -- 隐藏框体，清空缓存
  if mainFrame then mainFrame:Hide() end
  wipe(spellCache)
end

--- 从GUID解析NPC ID
--- @param guid string 单位GUID
--- @return number|nil npcID
function MT:GetNpcIDFromGUID(guid)
  if not guid then return nil end
  local npcID = select(6, strsplit("-", guid))
  return npcID and tonumber(npcID) or nil
end

--- 从NPCSpells数据表查找NPC数据
--- @param npcID number NPC ID
--- @return table|nil NPC数据
function MT:GetNpcData(npcID)
  if not npcID then return nil end
  return MT.NPCSpells and MT.NPCSpells[npcID] or nil
end

--- 进入大秘境时，按当前副本mapID只加载该副本NPC的技能信息到缓存
--- 每个副本约20-35个NPC，spellCache只缓存当前副本的技能，运行时零C_Spell调用
function MT:PreloadSpellCacheForCurrentDungeon()
  if not MT.DungeonNPCs or not MT.NPCSpells then return end

  local mapID = C_ChallengeMode.GetActiveChallengeMapID and C_ChallengeMode.GetActiveChallengeMapID()
  if not mapID then return end

  local npcIDs = MT.DungeonNPCs[mapID]
  if not npcIDs then return end

  for i = 1, #npcIDs do
    local npcID = npcIDs[i]
    local npcData = MT.NPCSpells[npcID]
    if npcData and npcData.spells then
      for _, spellEntry in ipairs(npcData.spells) do
        local spellID = spellEntry.spellID
        if spellID and not spellCache[spellID] then
          -- 借鉴MDT：异步预热spell数据，避免同步API阻塞
          if not C_Spell.IsSpellDataCached(spellID) then
            RequestLoadSpellData(spellID)
          end
          local name = GetSpellName(spellID)
          if name then
            spellCache[spellID] = {
              spellID = spellID,
              name = name,
              description = GetSpellDescription(spellID) or "",
              icon = GetSpellTexture(spellID),
            }
          end
        end
      end
    end
  end
end

--- 获取技能信息，缓存未命中时尝试调用API懒补入缓存
--- @param spellID number 技能ID
--- @return table|nil {name, description, icon}
function MT:GetSpellInfo(spellID)
  if not spellID then return nil end
  if spellCache[spellID] then
    return spellCache[spellID]
  end
  -- 运行时懒补：预加载阶段API偶发失败时，此处兜底补入缓存
  local name = GetSpellName(spellID)
  if not name then return nil end
  spellCache[spellID] = {
    spellID = spellID,
    name = name,
    description = GetSpellDescription(spellID) or "",
    icon = GetSpellTexture(spellID),
  }
  return spellCache[spellID]
end

-------------------------
--- 目标切换处理     ----
-------------------------
--- 目标切换事件回调，仅在大秘境内触发
function MT:OnTargetChanged()
  -- 非大秘境中不处理（双重保险，正常不会走到这里）
  if not inMythicPlus then return end
  if not db or not db.profile.enabled then
    if mainFrame then mainFrame:Hide() end
    return
  end

  local guid = UnitGUID("target")
  if not guid then
    lastNpcID = nil
    if mainFrame then mainFrame:Hide() end
    return
  end

  -- 仅对可攻击单位显示
  if not UnitCanAttack("player", "target") then
    lastNpcID = nil
    if mainFrame then mainFrame:Hide() end
    return
  end

  -- 战斗中是否显示
  if not db.profile.showInCombat and InCombatLockdown() then
    if mainFrame then mainFrame:Hide() end
    return
  end

  local npcID = MT:GetNpcIDFromGUID(guid)
  -- 跳过相同NPC的重复刷新
  if npcID == lastNpcID then return end

  local npcData = MT:GetNpcData(npcID)
  if not npcData then
    lastNpcID = nil
    if mainFrame then mainFrame:Hide() end
    return
  end

  lastNpcID = npcID
  local unitName = UnitName("target") or npcData.name or "Unknown"
  MT:UpdateMainFrame(unitName, npcID, npcData)
end

-------------------------
--- 主显示框        ----
-------------------------
--- 框体尺寸常量
local FRAME_WIDTH = 320
local FRAME_HEADER_HEIGHT = 30
local SPELL_LINE_HEIGHT = 22

--- 暗色系配色
local BG_COLOR = { 0.06, 0.06, 0.06, 0.9 }
local BORDER_COLOR = { 0.3, 0.3, 0.3, 0.8 }
local HEADER_COLOR = { 0.1, 0.1, 0.1, 0.95 }
local HIGHLIGHT_COLOR = { 0.2, 0.6, 1.0, 1.0 }
local INTERRUPTIBLE_COLOR = { 1.0, 0.3, 0.3, 1.0 }
local TEXT_COLOR = { 1, 1, 1, 1 }
local TIPS_COLOR = { 0, 1, 0.6, 1 }
local DEFAULT_TIPS_COLOR = { 1, 0.8, 0, 1 }

--- tag属性 -> 图标路径映射（WoW内置图标）
--- 仅enrage/magic/poison/bleed/disease/curse有tag图标，interruptible用右侧文字标记
local TAG_ICONS = {
  enrage   = "Interface\\Icons\\Ability_Warrior_Fury",
  magic    = "Interface\\Icons\\Spell_Arcane_Arcane01",
  poison   = "Interface\\Icons\\Spell_Nature_CorrosiveBreath",
  bleed    = "Interface\\Icons\\INV_Weapon_Shortblade_04",
  disease  = "Interface\\Icons\\Spell_Shadow_PlagueCloud",
  curse    = "Interface\\Icons\\Spell_Shadow_CurseOfSargeras",
}

--- tag属性显示顺序
local TAG_ORDER = { "enrage", "magic", "curse", "disease", "poison", "bleed" }

--- 创建主显示框，借鉴MDT的BackdropTemplate用法
function MT:CreateMainFrame()
  if mainFrame then return end

  local f = CreateFrame("Frame", "MythicTipsFrame", UIParent, "BackdropTemplate")
  f:SetSize(FRAME_WIDTH, 100)
  f:SetBackdrop({
    bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    edgeSize = 12,
    tile = true,
    tileSize = 16,
    insets = { left = 2, right = 2, top = 2, bottom = 2 },
  })
  f:SetBackdropColor(unpack(BG_COLOR))
  f:SetBackdropBorderColor(unpack(BORDER_COLOR))
  f:SetFrameStrata("HIGH")
  f:SetFrameLevel(100)
  f:EnableMouse(true)
  f:SetMovable(true)
  f:SetClampedToScreen(true)
  f:Hide()

  -- 标题栏
  f.header = CreateFrame("Frame", nil, f, "BackdropTemplate")
  f.header:SetHeight(FRAME_HEADER_HEIGHT)
  f.header:SetPoint("TOPLEFT", f, "TOPLEFT", 2, -2)
  f.header:SetPoint("TOPRIGHT", f, "TOPRIGHT", -2, -2)
  f.header:SetBackdrop({
    bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
  })
  f.header:SetBackdropColor(unpack(HEADER_COLOR))

  -- 拖动支持：仅在标题栏区域Shift+左键拖动
  -- 避免技能行EnableMouse拦截鼠标导致拖动失效
  f.header:EnableMouse(true)
  f.header:RegisterForDrag("LeftButton")
  f.header:SetScript("OnDragStart", function(self)
    if IsShiftKeyDown() then
      mainFrame:StartMoving()
    end
  end)
  f.header:SetScript("OnDragStop", function(self)
    mainFrame:StopMovingOrSizing()
    MT:SavePosition()
  end)

  -- 标题文字：怪物名称 + NPC ID
  f.titleText = f.header:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  f.titleText:SetPoint("LEFT", f.header, "LEFT", 8, 0)
  f.titleText:SetTextColor(unpack(HIGHLIGHT_COLOR))

  -- 关闭按钮
  f.closeButton = CreateFrame("Button", nil, f.header, "UIPanelCloseButton")
  f.closeButton:SetPoint("TOPRIGHT", f.header, "TOPRIGHT", 0, 4)
  f.closeButton:SetScript("OnClick", function()
    f:Hide()
  end)

  -- 内容区域（滚动支持）
  f.scrollFrame = CreateFrame("ScrollFrame", nil, f, "UIPanelScrollFrameTemplate")
  f.scrollFrame:SetPoint("TOPLEFT", f, "TOPLEFT", 4, -FRAME_HEADER_HEIGHT - 4)
  f.scrollFrame:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -20, 4)

  f.content = CreateFrame("Frame", nil, f.scrollFrame)
  f.content:SetSize(FRAME_WIDTH - 28, 1)
  f.scrollFrame:SetScrollChild(f.content)

  -- 技能行对象池
  f.spellFrames = {}

  -- 自定义心得文本
  f.tipsText = f.content:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  f.tipsText:SetPoint("TOPLEFT", f.content, "TOPLEFT", 8, 0)
  f.tipsText:SetPoint("RIGHT", f.content, "RIGHT", -8, 0)
  f.tipsText:SetJustifyH("LEFT")
  f.tipsText:SetJustifyV("TOP")
  f.tipsText:SetTextColor(unpack(TIPS_COLOR))

  -- 默认心得文本
  f.defaultTipsText = f.content:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  f.defaultTipsText:SetPoint("TOPLEFT", f.tipsText, "BOTTOMLEFT", 0, -2)
  f.defaultTipsText:SetPoint("RIGHT", f.content, "RIGHT", -8, 0)
  f.defaultTipsText:SetJustifyH("LEFT")
  f.defaultTipsText:SetJustifyV("TOP")
  f.defaultTipsText:SetTextColor(unpack(DEFAULT_TIPS_COLOR))

  -- 恢复保存的位置
  local pos = db.profile.position
  if pos then
    f:ClearAllPoints()
    f:SetPoint(pos.point or "CENTER", UIParent, pos.relPoint or "CENTER", pos.x or 0, pos.y or 0)
  end

  -- 应用显示设置
  f:SetScale(db.profile.display.scale or 1.0)
  f:SetAlpha(db.profile.display.alpha or 0.9)

  mainFrame = f
  MT.mainFrame = f
end

--- 获取或创建技能显示行（对象池复用）
--- @param index number 行索引
--- @return Frame spellRow
function MT:AcquireSpellRow(index)
  if mainFrame.spellFrames[index] then
    return mainFrame.spellFrames[index]
  end

  local row = CreateFrame("Frame", nil, mainFrame.content)
  row:SetHeight(SPELL_LINE_HEIGHT)

  -- 技能原图标
  row.icon = row:CreateTexture(nil, "ARTWORK")
  row.icon:SetSize(18, 18)
  row.icon:SetPoint("LEFT", row, "LEFT", 8, 0)

  -- 可打断标记（最右侧，右对齐）
  row.interruptTag = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  row.interruptTag:SetPoint("RIGHT", row, "RIGHT", -8, 0)
  row.interruptTag:SetTextColor(unpack(INTERRUPTIBLE_COLOR))

  -- 技能名称（左端锚到图标右端，左对齐，名称自适应宽度）
  row.name = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  row.name:SetPoint("LEFT", row.icon, "RIGHT", 4, 0)
  row.name:SetJustifyH("LEFT")
  row.name:SetTextColor(unpack(TEXT_COLOR))

  -- tag小图标（名称右侧，依次左对齐排列，自由扩展）
  -- 布局：[原图标][名称][tag1][tag2]...------[可打断]
  row.tagIcons = {}
  for ti = 1, 6 do
    local tagIcon = row:CreateTexture(nil, "ARTWORK")
    tagIcon:SetSize(12, 12)
    tagIcon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    tagIcon:Hide()
    row.tagIcons[ti] = tagIcon
  end
  -- 第一个tag锚到名称右端+2px间距
  row.tagIcons[1]:SetPoint("LEFT", row.name, "RIGHT", 2, 0)
  -- 后续tag依次右排
  for ti = 2, 6 do
    row.tagIcons[ti]:SetPoint("LEFT", row.tagIcons[ti - 1], "RIGHT", 2, 0)
  end

  -- 技能描述（点击展开/收起）
  row.desc = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  row.desc:SetPoint("TOPLEFT", row.name, "BOTTOMLEFT", 0, -2)
  row.desc:SetPoint("RIGHT", row, "RIGHT", -8, 0)
  row.desc:SetJustifyH("LEFT")
  row.desc:Hide()

  -- 点击切换描述显示（Shift键由父Frame处理拖动，不拦截）
  row:SetScript("OnMouseDown", function(self, button)
    if IsShiftKeyDown() then return end
    if self.desc:IsShown() then
      self.desc:Hide()
      self:SetHeight(SPELL_LINE_HEIGHT)
    else
      self.desc:Show()
      self:SetHeight(SPELL_LINE_HEIGHT + self.desc:GetHeight() + 4)
    end
    MT:RefreshLayout()
  end)

  row:EnableMouse(true)
  mainFrame.spellFrames[index] = row
  return row
end

--- 更新主框体内容
--- @param unitName string 怪物名称
--- @param npcID number NPC ID
--- @param npcData table NPC数据
function MT:UpdateMainFrame(unitName, npcID, npcData)
  if not mainFrame then return end

  -- 设置标题
  local bossTag = npcData.isBoss and " |cFFFF0000[BOSS]|r" or ""
  mainFrame.titleText:SetText(unitName .. bossTag .. "  |cFF888888npc:" .. npcID .. "|r")

  -- 隐藏超出当前技能数量的行
  local spellCount = npcData.spells and #npcData.spells or 0
  for i = #mainFrame.spellFrames, spellCount + 1, -1 do
    mainFrame.spellFrames[i]:Hide()
  end

  -- 填充技能列表
  local offsetY = 0
  local spells = npcData.spells or {}
  for i, spellEntry in ipairs(spells) do
    local row = MT:AcquireSpellRow(i)
    local info = MT:GetSpellInfo(spellEntry.spellID)
    if info then
      row.icon:SetTexture(info.icon or 134400)
      row.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
      row.name:SetText(info.name)

      -- 填充tag小图标（enrage/magic/poison/bleed/disease/curse）
      local tagIdx = 0
      for _, tagKey in ipairs(TAG_ORDER) do
        if spellEntry[tagKey] then
          tagIdx = tagIdx + 1
          if tagIdx <= 6 then
            row.tagIcons[tagIdx]:SetTexture(TAG_ICONS[tagKey])
            row.tagIcons[tagIdx]:Show()
          end
        end
      end
      -- 隐藏未使用的tag图标
      for ti = tagIdx + 1, 6 do
        row.tagIcons[ti]:Hide()
      end

      -- 可打断标记
      if spellEntry.interruptible then
        row.interruptTag:SetText("|cFFFF3333[可打断]|r")
        row.interruptTag:Show()
      else
        row.interruptTag:Hide()
      end
      if db.profile.showSpellDesc and info.description ~= "" then
        row.desc:SetText(info.description)
      else
        row.desc:Hide()
      end
    else
      row.icon:SetTexture(134400)
      row.name:SetText("Spell #" .. spellEntry.spellID)
      row.interruptTag:Hide()
      row.desc:Hide()
      -- 清空tag图标
      for ti = 1, 6 do
        row.tagIcons[ti]:Hide()
      end
    end
    row:ClearAllPoints()
    row:SetPoint("TOPLEFT", mainFrame.content, "TOPLEFT", 0, -offsetY)
    row:SetPoint("RIGHT", mainFrame.content, "RIGHT", 0, 0)
    row:SetHeight(SPELL_LINE_HEIGHT)
    row:Show()
    offsetY = offsetY + SPELL_LINE_HEIGHT
  end

  -- 自定义心得（统一用number key）
  local tipsY = offsetY
  if db.profile.showCustomTips then
    local customText = db.profile.customTips[npcID] or ""
    if customText ~= "" then
      mainFrame.tipsText:SetText("|cFF00FF99[心得]|r " .. customText)
      mainFrame.tipsText:ClearAllPoints()
      mainFrame.tipsText:SetPoint("TOPLEFT", mainFrame.content, "TOPLEFT", 0, -tipsY)
      mainFrame.tipsText:Show()
      tipsY = tipsY + mainFrame.tipsText:GetHeight() + 4
    else
      mainFrame.tipsText:Hide()
    end
  else
    mainFrame.tipsText:Hide()
  end

  -- 默认心得（统一用number key）
  if db.profile.showDefaultTips then
    local defaultText = db.profile.defaultTips[npcID] or ""
    if defaultText ~= "" then
      mainFrame.defaultTipsText:SetText("|cFFFFCC00[默认心得]|r " .. defaultText)
      mainFrame.defaultTipsText:ClearAllPoints()
      mainFrame.defaultTipsText:SetPoint("TOPLEFT", mainFrame.content, "TOPLEFT", 0, -tipsY)
      mainFrame.defaultTipsText:Show()
      tipsY = tipsY + mainFrame.defaultTipsText:GetHeight() + 4
    else
      mainFrame.defaultTipsText:Hide()
    end
  else
    mainFrame.defaultTipsText:Hide()
  end

  -- 无技能也无心得时不显示空框
  if tipsY == 0 then
    mainFrame:Hide()
    return
  end

  -- 更新内容高度和框体高度
  mainFrame.content:SetHeight(tipsY)
  local totalHeight = FRAME_HEADER_HEIGHT + 8 + tipsY + 8
  totalHeight = math.max(totalHeight, 60)
  totalHeight = math.min(totalHeight, 500)
  mainFrame:SetHeight(totalHeight)

  mainFrame:Show()
end

--- 刷新框体布局（技能描述展开/收起后调用）
function MT:RefreshLayout()
  if not mainFrame then return end
  local offsetY = 0
  for _, row in ipairs(mainFrame.spellFrames) do
    if row:IsShown() then
      row:ClearAllPoints()
      row:SetPoint("TOPLEFT", mainFrame.content, "TOPLEFT", 0, -offsetY)
      row:SetPoint("RIGHT", mainFrame.content, "RIGHT", 0, 0)
      if row.desc:IsShown() then
        row:SetHeight(SPELL_LINE_HEIGHT + row.desc:GetHeight() + 4)
      else
        row:SetHeight(SPELL_LINE_HEIGHT)
      end
      offsetY = offsetY + row:GetHeight()
    end
  end

  local tipsY = offsetY
  if mainFrame.tipsText:IsShown() then
    mainFrame.tipsText:ClearAllPoints()
    mainFrame.tipsText:SetPoint("TOPLEFT", mainFrame.content, "TOPLEFT", 0, -tipsY)
    tipsY = tipsY + mainFrame.tipsText:GetHeight() + 4
  end
  if mainFrame.defaultTipsText:IsShown() then
    mainFrame.defaultTipsText:ClearAllPoints()
    mainFrame.defaultTipsText:SetPoint("TOPLEFT", mainFrame.content, "TOPLEFT", 0, -tipsY)
    tipsY = tipsY + mainFrame.defaultTipsText:GetHeight() + 4
  end

  mainFrame.content:SetHeight(tipsY > 0 and tipsY or 1)
  local totalHeight = FRAME_HEADER_HEIGHT + 8 + tipsY + 8
  totalHeight = math.max(totalHeight, 60)
  totalHeight = math.min(totalHeight, 500)
  mainFrame:SetHeight(totalHeight)
end

--- 保存框体位置到AceDB
function MT:SavePosition()
  if not mainFrame then return end
  local point, _, relPoint, x, y = mainFrame:GetPoint()
  if not point then return end
  db.profile.position = {
    point = point,
    relPoint = relPoint,
    x = x,
    y = y,
  }
end

--- 切换主框体显隐
function MT:ToggleFrame()
  if not mainFrame then return end
  if mainFrame:IsShown() then
    mainFrame:Hide()
  else
    mainFrame:Show()
  end
end

-------------------------
--- 配置面板        ----
-------------------------
--- 注册AceConfig配置面板
function MT:RegisterConfig()
  local AceConfig = LibStub("AceConfig-3.0")
  local AceConfigDialog = LibStub("AceConfigDialog-3.0")
  local options = {
    name = "MythicTips",
    type = "group",
    args = {
      general = {
        name = "通用设置",
        type = "group",
        order = 1,
        args = {
          enabled = {
            name = "启用插件",
            desc = "开启/关闭MythicTips提示功能",
            type = "toggle",
            order = 1,
            get = function() return db.profile.enabled end,
            set = function(_, val) db.profile.enabled = val end,
          },
          showInCombat = {
            name = "战斗中显示",
            desc = "战斗中是否显示提示框",
            type = "toggle",
            order = 2,
            get = function() return db.profile.showInCombat end,
            set = function(_, val) db.profile.showInCombat = val end,
          },
          showSpellDesc = {
            name = "显示技能描述",
            desc = "点击技能行时展开描述",
            type = "toggle",
            order = 3,
            get = function() return db.profile.showSpellDesc end,
            set = function(_, val) db.profile.showSpellDesc = val end,
          },
          showCustomTips = {
            name = "显示自定义心得",
            desc = "显示玩家自定义的应对心得",
            type = "toggle",
            order = 4,
            get = function() return db.profile.showCustomTips end,
            set = function(_, val) db.profile.showCustomTips = val end,
          },
          showDefaultTips = {
            name = "显示默认心得",
            desc = "显示插件内置的默认应对心得",
            type = "toggle",
            order = 5,
            get = function() return db.profile.showDefaultTips end,
            set = function(_, val) db.profile.showDefaultTips = val end,
          },
          scale = {
            name = "缩放",
            desc = "提示框缩放比例",
            type = "range",
            order = 6,
            min = 0.5,
            max = 2.0,
            step = 0.1,
            get = function() return db.profile.display.scale end,
            set = function(_, val) db.profile.display.scale = val end,
          },
          alpha = {
            name = "透明度",
            desc = "提示框透明度",
            type = "range",
            order = 7,
            min = 0.1,
            max = 1.0,
            step = 0.1,
            get = function() return db.profile.display.alpha end,
            set = function(_, val) db.profile.display.alpha = val end,
          },
        },
      },
      tips = {
        name = "心得编辑",
        type = "group",
        order = 2,
        args = {
          npcIdInput = {
            name = "NPC ID",
            desc = "输入要编辑心得的NPC ID",
            type = "input",
            order = 1,
            get = function() return MT._configNpcID or "" end,
            set = function(_, val) MT._configNpcID = val end,
          },
          customTips = {
            name = "自定义心得",
            desc = "为指定NPC编辑自定义应对心得",
            type = "input",
            order = 2,
            multiline = true,
            width = "full",
            get = function()
              local npcID = MT._configNpcID
              if not npcID or npcID == "" then return "" end
              return db.profile.customTips[tonumber(npcID)] or ""
            end,
            set = function(_, val)
              local npcID = MT._configNpcID
              if npcID and npcID ~= "" then
                db.profile.customTips[tonumber(npcID)] = val ~= "" and val or nil
              end
            end,
          },
          defaultTips = {
            name = "默认心得",
            desc = "为指定NPC编辑默认应对心得",
            type = "input",
            order = 3,
            multiline = true,
            width = "full",
            get = function()
              local npcID = MT._configNpcID
              if not npcID or npcID == "" then return "" end
              return db.profile.defaultTips[tonumber(npcID)] or ""
            end,
            set = function(_, val)
              local npcID = MT._configNpcID
              if npcID and npcID ~= "" then
                db.profile.defaultTips[tonumber(npcID)] = val ~= "" and val or nil
              end
            end,
          },
          exportBtn = {
            name = "导出自定义心得",
            desc = "将所有自定义心得导出为字符串，方便分享",
            type = "execute",
            order = 4,
            func = function()
              MT:ExportCustomTips()
            end,
          },
          importBtn = {
            name = "导入自定义心得",
            desc = "从字符串导入自定义心得",
            type = "input",
            order = 5,
            multiline = true,
            width = "full",
            get = function() return "" end,
            set = function(_, val)
              if val and val ~= "" then
                MT:ImportCustomTips(val)
              end
            end,
          },
        },
      },
    },
  }

  AceConfig:RegisterOptionsTable("MythicTips", options)
  AceConfigDialog:AddToBlizOptions("MythicTips", "MythicTips")
end

--- 打开配置面板
function MT:OpenConfig()
  InterfaceOptionsFrame_OpenToCategory("MythicTips")
  InterfaceOptionsFrame_OpenToCategory("MythicTips")
end

--- 导出自定义心得为序列化字符串
function MT:ExportCustomTips()
  local tips = db.profile.customTips
  if not tips or next(tips) == nil then
    print("|cFFFF0000MythicTips:|r 没有自定义心得可导出")
    return
  end
  local serial = LibStub("AceSerializer-3.0")
  local data = serial:Serialize(tips)
  -- 复制到剪贴板
  local editBox = ChatEdit_ChooseBoxToSend()
  if editBox then
    ChatEdit_ActivateChat(editBox)
    editBox:SetText(data)
    print("|cFF00FF00MythicTips:|r 自定义心得已复制到聊天框，按Enter发送或Ctrl+C复制")
  else
    print("|cFFFF0000MythicTips:|r 导出失败，无法访问聊天框")
  end
end

--- 从序列化字符串导入自定义心得
--- @param dataString string 序列化的心得数据
function MT:ImportCustomTips(dataString)
  local serial = LibStub("AceSerializer-3.0")
  local ok, imported = serial:Deserialize(dataString)
  if not ok or type(imported) ~= "table" then
    print("|cFFFF0000MythicTips:|r 导入失败，数据格式无效")
    return
  end
  for npcID, text in pairs(imported) do
    -- 兼容string和number两种key格式
    db.profile.customTips[tonumber(npcID) or npcID] = text
  end
  print("|cFF00FF00MythicTips:|r 成功导入 " .. MT:CountTable(imported) .. " 条自定义心得")
end

--- 计算表元素数量
--- @param t table 要计数的表
--- @return number count
function MT:CountTable(t)
  local count = 0
  for _ in pairs(t) do count = count + 1 end
  return count
end