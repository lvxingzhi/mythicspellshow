--- MythicTips: 大秘境怪物机制提示插件
--- 目标切换敌对NPC时弹出暗色系UI框显示技能信息
--- @author ext.ahs.lvxingz1

local AddonName, MT = ...
_G["MT"] = MT

local LibStub = LibStub

local unpack = unpack or table.unpack
local CreateFrame, tonumber, select, strsplit, pairs, ipairs =
    CreateFrame, tonumber, select, strsplit, pairs, ipairs
local UnitGUID, UnitName, UnitCanAttack =
    UnitGUID, UnitName, UnitCanAttack
local GetSpellName, GetSpellDescription, GetSpellTexture =
    C_Spell.GetSpellName, C_Spell.GetSpellDescription, C_Spell.GetSpellTexture
local RequestLoadSpellData = C_Spell.RequestLoadSpellData

local C = MT.Config

local db
local mainFrame
local spellCache = {}
local lastNpcID

-------------------------
--- 斜杠命令        ----
-------------------------
SLASH_MythicTips = "/mythictips"

function SlashCmdList.MythicTips(cmd)
  cmd = cmd and cmd:lower() or ""
  if cmd == "reset" then
    if mainFrame then
      mainFrame:ClearAllPoints()
      mainFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
      MT:SavePosition()
      print("|cFF00FF00MythicTips:|r 位置已重置")
    end
  elseif cmd == "config" or cmd == "options" then
    MT:OpenConfig()
  elseif cmd == "debug" then
    MT:PrintDebugInfo()
  elseif cmd == "show" then
    MT:ShowFrameSmart()
  elseif cmd == "hide" then
    MT:CloseFrame()
  else
    MT:ToggleFrame()
  end
end

-------------------------
--- 初始化          ----
-------------------------
local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("ADDON_LOADED")

eventFrame:SetScript("OnEvent", function(self, event, ...)
  if event == "ADDON_LOADED" then
    local addon = ...
    if addon == "MythicTips" then
      MT:OnInitialize()
      self:UnregisterEvent("ADDON_LOADED")
    end
  elseif event == "PLAYER_TARGET_CHANGED" then
    MT:OnTargetChanged()
  end
end)

--- 插件初始化，ADDON_LOADED时调用
function MT:OnInitialize()
  local AceDB = LibStub("AceDB-3.0")
  db = AceDB:New("MythicTipsDB", C.DEFAULTS, true)
  MT.db = db

  MT:RegisterConfig()
  MT:CreateMainFrame()
  MT:PreloadAllSpellCache()

  print("|cFF00FF00MythicTips|r 已加载。输入 |cFFFFFF00/mythictips|r 切换显示。")
end

--- 从GUID解析NPC ID
--- @param guid string 单位GUID
--- @return number|nil npcID
function MT:GetNpcIDFromGUID(guid)
  if not guid then return nil end
  local npcID = select(6, strsplit("-", guid))
  return npcID and tonumber(npcID) or nil
end

--- 从NPCSpells数据表查找NPC数据
--- @param npcID number NPC ID
--- @return table|nil NPC数据
function MT:GetNpcData(npcID)
  if not npcID then return nil end
  return MT.NPCSpells and MT.NPCSpells[npcID] or nil
end

--- 一次性预加载所有NPC的技能信息到缓存
function MT:PreloadAllSpellCache()
  if not MT.NPCSpells then return end
  for _, npcData in pairs(MT.NPCSpells) do
    if npcData and npcData.spells then
      for _, spellEntry in ipairs(npcData.spells) do
        local spellID = spellEntry.spellID
        if spellID and not spellCache[spellID] then
          if not C_Spell.IsSpellDataCached(spellID) then
            RequestLoadSpellData(spellID)
          end
          local name = GetSpellName(spellID)
          if name then
            spellCache[spellID] = {
              spellID = spellID,
              name = name,
              description = GetSpellDescription(spellID) or "",
              icon = GetSpellTexture(spellID),
            }
          end
        end
      end
    end
  end
end

--- 获取技能信息，缓存未命中时尝试调用API补入缓存
--- @param spellID number 技能ID
--- @return table|nil {name, description, icon}
function MT:GetSpellInfo(spellID)
  if not spellID then return nil end
  if spellCache[spellID] then return spellCache[spellID] end
  local name = GetSpellName(spellID)
  if not name then return nil end
  spellCache[spellID] = {
    spellID = spellID,
    name = name,
    description = GetSpellDescription(spellID) or "",
    icon = GetSpellTexture(spellID),
  }
  return spellCache[spellID]
end

-------------------------
--- 目标切换处理     ----
-------------------------
local function showPlaceholderIfShown()
  if mainFrame and mainFrame:IsShown() then MT:ShowPlaceholder() end
end

--- 目标切换事件回调，框体打开时触发
--- 切换目标时自动刷新内容，无命中数据则显示占位提示
function MT:OnTargetChanged()
  if not db then
    showPlaceholderIfShown()
    return
  end

  local guid = UnitGUID("target")
  if not guid then
    lastNpcID = nil
    showPlaceholderIfShown()
    return
  end

  if not UnitCanAttack("player", "target") then
    lastNpcID = nil
    showPlaceholderIfShown()
    return
  end

  local npcID = MT:GetNpcIDFromGUID(guid)
  if npcID == lastNpcID then return end

  local npcData = MT:GetNpcData(npcID)
  if not npcData then
    lastNpcID = nil
    showPlaceholderIfShown()
    return
  end

  lastNpcID = npcID
  MT:UpdateMainFrame(UnitName("target") or npcData.name or "Unknown", npcID, npcData)
end

-------------------------
--- 主显示框        ----
-------------------------
--- 创建主显示框
function MT:CreateMainFrame()
  if mainFrame then return end

  local frameWidth = db.profile.display.frameWidth or C.FRAME_WIDTH

  local f = CreateFrame("Frame", "MythicTipsFrame", UIParent, "BackdropTemplate")
  f:SetSize(frameWidth, 100)
  f:SetBackdrop({
    bgFile = "Interface\\Buttons\\WHITE8x8",
    edgeFile = "Interface\\Buttons\\WHITE8x8",
    edgeSize = 1,
    insets = { left = 0, right = 0, top = 0, bottom = 0 },
  })
  f:SetBackdropColor(unpack(C.BG_COLOR))
  f:SetBackdropBorderColor(unpack(C.BORDER_COLOR))
  f:SetFrameStrata("HIGH")
  f:SetFrameLevel(100)
  f:EnableMouse(true)
  f:SetMovable(true)
  f:SetClampedToScreen(true)
  f:Hide()

  -- 标题栏
  f.header = CreateFrame("Frame", nil, f, "BackdropTemplate")
  f.header:SetHeight(C.FRAME_HEADER_HEIGHT)
  f.header:SetPoint("TOPLEFT", f, "TOPLEFT", 1, -1)
  f.header:SetPoint("TOPRIGHT", f, "TOPRIGHT", -1, -1)
  f.header:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8" })
  f.header:SetBackdropColor(unpack(C.HEADER_COLOR))

  -- 标题栏底部分隔线
  f.headerLine = f.header:CreateTexture(nil, "ARTWORK")
  f.headerLine:SetHeight(1)
  f.headerLine:SetPoint("BOTTOMLEFT", f.header, "BOTTOMLEFT", 0, 0)
  f.headerLine:SetPoint("BOTTOMRIGHT", f.header, "BOTTOMRIGHT", 0, 0)
  f.headerLine:SetColorTexture(unpack(C.HEADER_LINE_COLOR))

  -- 拖动支持
  f.header:EnableMouse(true)
  f.header:RegisterForDrag("LeftButton")
  f.header:SetScript("OnDragStart", function() mainFrame:StartMoving() end)
  f.header:SetScript("OnDragStop", function()
    mainFrame:StopMovingOrSizing()
    MT:SavePosition()
  end)

  -- 标题文字
  f.titleText = f.header:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  f.titleText:SetPoint("LEFT", f.header, "LEFT", 8, 0)
  f.titleText:SetPoint("RIGHT", f.header, "RIGHT", -24, 0)
  f.titleText:SetJustifyH("LEFT")
  f.titleText:SetTextColor(unpack(C.TITLE_COLOR))

  -- 关闭按钮
  f.closeButton = CreateFrame("Button", nil, f.header, "BackdropTemplate")
  f.closeButton:SetSize(20, 20)
  f.closeButton:SetPoint("RIGHT", f.header, "RIGHT", -2, 0)
  f.closeButton:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8" })
  f.closeButton:SetBackdropColor(0, 0, 0, 0)
  f.closeButton.text = f.closeButton:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  f.closeButton.text:SetPoint("CENTER", f.closeButton, "CENTER", 0, 0)
  f.closeButton.text:SetText("×")
  f.closeButton.text:SetTextColor(unpack(C.CLOSE_NORMAL_COLOR))
  f.closeButton.text:SetFont("Fonts\\FRIZQT__.TTF", 14, "OUTLINE")
  f.closeButton:SetScript("OnEnter", function(self)
    self:SetBackdropColor(0.5, 0.1, 0.1, 0.6)
    self.text:SetTextColor(unpack(C.CLOSE_HOVER_COLOR))
  end)
  f.closeButton:SetScript("OnLeave", function(self)
    self:SetBackdropColor(0, 0, 0, 0)
    self.text:SetTextColor(unpack(C.CLOSE_NORMAL_COLOR))
  end)
  f.closeButton:SetScript("OnClick", function() MT:CloseFrame() end)

  -- 滚动区域
  f.scrollFrame = CreateFrame("ScrollFrame", nil, f)
  f.scrollFrame:SetPoint("TOPLEFT", f, "TOPLEFT", 4, -C.FRAME_HEADER_HEIGHT - 4)
  f.scrollFrame:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -4, 4)

  f.content = CreateFrame("Frame", nil, f.scrollFrame)
  f.content:SetWidth(frameWidth - 10)
  f.content:SetHeight(1)
  f.scrollFrame:SetScrollChild(f.content)

  -- 自定义滚动条
  f.scrollBar = CreateFrame("Slider", nil, f, "BackdropTemplate")
  f.scrollBar:SetOrientation("VERTICAL")
  f.scrollBar:SetWidth(C.SCROLLBAR_WIDTH)
  f.scrollBar:SetPoint("TOPRIGHT", f, "TOPRIGHT", -2, -C.FRAME_HEADER_HEIGHT - 4)
  f.scrollBar:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -2, 4)
  f.scrollBar:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8" })
  f.scrollBar:SetBackdropColor(0.15, 0.15, 0.15, 0.40)
  f.scrollBar:SetThumbTexture("Interface\\Buttons\\WHITE8x8")
  local thumb = f.scrollBar:GetThumbTexture()
  thumb:SetWidth(C.SCROLLBAR_WIDTH)
  thumb:SetHeight(30)
  thumb:SetColorTexture(0.55, 0.55, 0.55, 0.70)
  f.scrollBar:SetMinMaxValues(0, 1)
  f.scrollBar:SetValue(0)
  f.scrollBar:Hide()

  f.scrollFrame:SetScript("OnScrollRangeChanged", function(_, _, yrange)
    if yrange <= 0 then
      f.scrollBar:Hide()
      f.scrollFrame:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -4, 4)
    else
      f.scrollBar:Show()
      f.scrollFrame:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -4 - C.SCROLLBAR_WIDTH - 2, 4)
      f.scrollBar:SetMinMaxValues(0, yrange)
    end
  end)
  f.scrollFrame:SetScript("OnVerticalScroll", function(_, offset)
    f.scrollBar:SetValue(offset)
  end)
  f.scrollBar:SetScript("OnValueChanged", function(self, value)
    f.scrollFrame:SetVerticalScroll(value)
  end)

  -- 滚轮支持
  f:EnableMouseWheel(true)
  f:SetScript("OnMouseWheel", function(_, delta)
    local current = f.scrollBar:GetValue()
    local minVal, maxVal = f.scrollBar:GetMinMaxValues()
    f.scrollBar:SetValue(math.max(minVal, math.min(maxVal, current - delta * 20)))
  end)

  f.spellFrames = {}

  -- 占位提示文本
  f.placeholderText = f.content:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  f.placeholderText:SetPoint("TOPLEFT", f.content, "TOPLEFT", 8, 0)
  f.placeholderText:SetPoint("RIGHT", f.content, "RIGHT", -8, 0)
  f.placeholderText:SetJustifyH("LEFT")
  f.placeholderText:SetJustifyV("TOP")
  f.placeholderText:SetTextColor(0.30, 1.00, 0.70, 1.0)

  -- 恢复位置与显示设置
  local pos = db.profile.position
  if pos then
    f:ClearAllPoints()
    f:SetPoint(pos.point or "CENTER", UIParent, pos.relPoint or "CENTER", pos.x or 0, pos.y or 0)
  end
  f:SetAlpha(db.profile.display.alpha or 0.9)

  mainFrame = f
  MT.mainFrame = f
end

--- 获取或创建技能显示行（对象池复用）
--- @param index number 行索引
--- @return Frame spellRow
function MT:AcquireSpellRow(index)
  if mainFrame.spellFrames[index] then return mainFrame.spellFrames[index] end

  local row = CreateFrame("Frame", nil, mainFrame.content, "BackdropTemplate")
  row:SetHeight(C.SPELL_LINE_HEIGHT)
  row:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8" })
  row:SetBackdropColor(0, 0, 0, 0)
  row:SetScript("OnEnter", function(self)
    self:SetBackdropColor(unpack(C.ROW_HOVER_COLOR))
  end)
  row:SetScript("OnLeave", function(self)
    self:SetBackdropColor(0, 0, 0, 0)
  end)

  -- 技能图标
  row.icon = row:CreateTexture(nil, "ARTWORK")
  row.icon:SetSize(18, 18)
  row.icon:SetPoint("LEFT", row, "LEFT", 8, 0)

  -- 可打断标记
  row.interruptTag = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
  row.interruptTag:SetPoint("RIGHT", row, "RIGHT", -8, 0)
  row.interruptTag:SetTextColor(unpack(C.INTERRUPTIBLE_COLOR))

  -- 技能名称
  row.name = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  row.name:SetPoint("LEFT", row.icon, "RIGHT", 4, 0)
  row.name:SetJustifyH("LEFT")
  row.name:SetTextColor(unpack(C.TEXT_COLOR))

  -- tag小图标
  row.tagIcons = {}
  for ti = 1, 6 do
    local tagIcon = row:CreateTexture(nil, "ARTWORK")
    tagIcon:SetSize(12, 12)
    tagIcon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    tagIcon:Hide()
    row.tagIcons[ti] = tagIcon
  end
  row.tagIcons[1]:SetPoint("LEFT", row.name, "RIGHT", 2, 0)
  for ti = 2, 6 do
    row.tagIcons[ti]:SetPoint("LEFT", row.tagIcons[ti - 1], "RIGHT", 2, 0)
  end

  -- 技能描述（点击展开/收起）
  row.desc = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  row.desc:SetPoint("TOPLEFT", row.name, "BOTTOMLEFT", 0, -2)
  row.desc:SetPoint("RIGHT", row, "RIGHT", -8, 0)
  row.desc:SetJustifyH("LEFT")
  row.desc:Hide()

  row:SetScript("OnMouseDown", function(self)
    if self.desc:IsShown() then
      self.desc:Hide()
      self:SetHeight(C.SPELL_LINE_HEIGHT)
    else
      self.desc:Show()
      self:SetHeight(C.SPELL_LINE_HEIGHT + self.desc:GetHeight() + 4)
    end
    MT:RefreshLayout()
  end)

  row:EnableMouse(true)
  mainFrame.spellFrames[index] = row
  return row
end

--- 计算框体总高度并应用
local function applyFrameSize(contentHeight)
  local maxHeight = db.profile.display.maxHeight or 800
  local frameWidth = db.profile.display.frameWidth or C.FRAME_WIDTH
  mainFrame.content:SetHeight(contentHeight > 0 and contentHeight or 1)
  mainFrame.content:SetWidth(frameWidth - 10)
  local totalHeight = C.FRAME_HEADER_HEIGHT + 8 + contentHeight + 8
  totalHeight = math.max(totalHeight, 60)
  totalHeight = math.min(totalHeight, maxHeight)
  mainFrame:SetWidth(frameWidth)
  mainFrame:SetHeight(totalHeight)
end

--- 更新主框体内容
--- @param unitName string 怪物名称
--- @param npcID number NPC ID
--- @param npcData table NPC数据
function MT:UpdateMainFrame(unitName, npcID, npcData)
  if not mainFrame then return end

  local bossTag = npcData.isBoss and " |cFFFF0000[BOSS]|r" or ""
  mainFrame.titleText:SetText(unitName .. bossTag .. "  |cFF888888npc:" .. npcID .. "|r")

  -- 隐藏占位文本
  mainFrame.placeholderText:Hide()
  -- 隐藏多余行
  local spellCount = npcData.spells and #npcData.spells or 0
  for i = #mainFrame.spellFrames, spellCount + 1, -1 do
    mainFrame.spellFrames[i]:Hide()
  end

  -- 填充技能列表
  local offsetY = 0
  for i, spellEntry in ipairs(npcData.spells or {}) do
    local row = MT:AcquireSpellRow(i)
    local info = MT:GetSpellInfo(spellEntry.spellID)
    if info then
      row.icon:SetTexture(info.icon or 134400)
      row.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
      row.name:SetText(info.name)

      local tagIdx = 0
      for _, tagKey in ipairs(C.TAG_ORDER) do
        if spellEntry[tagKey] then
          tagIdx = tagIdx + 1
          if tagIdx <= 6 then
            row.tagIcons[tagIdx]:SetTexture(C.TAG_ICONS[tagKey])
            row.tagIcons[tagIdx]:Show()
          end
        end
      end
      for ti = tagIdx + 1, 6 do
        row.tagIcons[ti]:Hide()
      end

      if spellEntry.interruptible then
        row.interruptTag:SetText("|cFFFF3333[可打断]|r")
        row.interruptTag:Show()
      else
        row.interruptTag:Hide()
      end

      -- 始终填充技能描述（点击行展开查看）
      if info.description ~= "" then
        row.desc:SetText(info.description)
      else
        row.desc:Hide()
      end
    else
      row.icon:SetTexture(134400)
      row.name:SetText("Spell #" .. spellEntry.spellID)
      row.interruptTag:Hide()
      row.desc:Hide()
      for ti = 1, 6 do
        row.tagIcons[ti]:Hide()
      end
    end
    row:ClearAllPoints()
    row:SetPoint("TOPLEFT", mainFrame.content, "TOPLEFT", 0, -offsetY)
    row:SetPoint("RIGHT", mainFrame.content, "RIGHT", 0, 0)
    row:SetHeight(C.SPELL_LINE_HEIGHT)
    row:Show()
    offsetY = offsetY + C.SPELL_LINE_HEIGHT
  end

  if offsetY == 0 then
    MT:ShowPlaceholder()
    return
  end

  applyFrameSize(offsetY)
  mainFrame:Show()
end

--- 刷新框体布局（技能描述展开/收起后调用）
function MT:RefreshLayout()
  if not mainFrame then return end
  local offsetY = 0
  for _, row in ipairs(mainFrame.spellFrames) do
    if row:IsShown() then
      row:ClearAllPoints()
      row:SetPoint("TOPLEFT", mainFrame.content, "TOPLEFT", 0, -offsetY)
      row:SetPoint("RIGHT", mainFrame.content, "RIGHT", 0, 0)
      if row.desc:IsShown() then
        row:SetHeight(C.SPELL_LINE_HEIGHT + row.desc:GetHeight() + 4)
      else
        row:SetHeight(C.SPELL_LINE_HEIGHT)
      end
      offsetY = offsetY + row:GetHeight()
    end
  end
  applyFrameSize(offsetY)
end

--- 保存框体位置到AceDB
function MT:SavePosition()
  if not mainFrame then return end
  local point, _, relPoint, x, y = mainFrame:GetPoint()
  if not point then return end
  db.profile.position = {
    point = point,
    relPoint = relPoint,
    x = x,
    y = y,
  }
end

--- 切换主框体显隐
function MT:ToggleFrame()
  if not mainFrame then return end
  if mainFrame:IsShown() then
    MT:CloseFrame()
  else
    MT:ShowFrameSmart()
  end
end

--- 智能显示主框体，打开时注册目标切换事件并检测当前目标
function MT:ShowFrameSmart()
  if not mainFrame then return end
  if not eventFrame:IsEventRegistered("PLAYER_TARGET_CHANGED") then
    eventFrame:RegisterEvent("PLAYER_TARGET_CHANGED")
  end
  local guid = UnitGUID("target")
  if guid and UnitCanAttack("player", "target") then
    local npcID = MT:GetNpcIDFromGUID(guid)
    local npcData = MT:GetNpcData(npcID)
    if npcID and npcData then
      MT:UpdateMainFrame(UnitName("target") or npcData.name or "Unknown", npcID, npcData)
      return
    end
  end
  MT:ShowPlaceholder()
end

--- 关闭框体并注销目标切换事件
function MT:CloseFrame()
  if not mainFrame then return end
  mainFrame:Hide()
  lastNpcID = nil
  if eventFrame:IsEventRegistered("PLAYER_TARGET_CHANGED") then
    eventFrame:UnregisterEvent("PLAYER_TARGET_CHANGED")
  end
end

--- 显示占位提示（手动打开但无目标命中时使用）
function MT:ShowPlaceholder()
  if not mainFrame then return end
  for _, row in ipairs(mainFrame.spellFrames) do
    row:Hide()
  end
  mainFrame.titleText:SetText("MythicTips")
  local hint = "请选中一只怪物以查看技能信息。\n命令：/mythictips reset 重置位置；/mythictips config 设置；/mythictips debug 排查。"
  mainFrame.placeholderText:SetText("|cFF00FF99[提示]|r " .. hint)
  mainFrame.placeholderText:ClearAllPoints()
  mainFrame.placeholderText:SetPoint("TOPLEFT", mainFrame.content, "TOPLEFT", 0, 0)
  mainFrame.placeholderText:SetPoint("RIGHT", mainFrame.content, "RIGHT", 0, 0)
  mainFrame.placeholderText:Show()
  local h = mainFrame.placeholderText:GetStringHeight() + 8
  mainFrame.content:SetHeight(math.max(h, 1))
  local frameWidth = db.profile.display.frameWidth or C.FRAME_WIDTH
  mainFrame.content:SetWidth(frameWidth - 10)
  local totalHeight = C.FRAME_HEADER_HEIGHT + 8 + h + 8
  mainFrame:SetWidth(frameWidth)
  mainFrame:SetHeight(math.max(math.min(totalHeight, db.profile.display.maxHeight or 800), 80))
  mainFrame:Show()
end

--- 打印调试信息，便于排查问题
function MT:PrintDebugInfo()
  print("|cFFFFFF00=== MythicTips Debug ===|r")
  print("NPCSpells 数据条目数:", MT.NPCSpells and MT:CountTable(MT.NPCSpells) or 0)
  local guid = UnitGUID("target")
  if guid then
    local npcID = MT:GetNpcIDFromGUID(guid)
    print("目标 GUID:", guid)
    print("目标 NPC ID:", tostring(npcID))
    print("可攻击:", tostring(UnitCanAttack("player", "target")))
    local data = MT:GetNpcData(npcID)
    if data then
      print("|cFF00FF00数据命中|r：", data.name, "技能数:", data.spells and #data.spells or 0)
    else
      print("|cFFFF6666数据未命中|r（该 NPC 未在 NPCSpells 中收录）")
    end
  else
    print("当前无目标")
  end
  print("框体可见:", mainFrame and mainFrame:IsShown() or false)
  print("PLAYER_TARGET_CHANGED 已注册:", eventFrame:IsEventRegistered("PLAYER_TARGET_CHANGED"))
  print("spellCache 条目数:", MT:CountTable(spellCache))
  print("|cFFFFFF00=========================|r")
end

-------------------------
--- 配置面板        ----
-------------------------
--- 注册AceConfig配置面板
function MT:RegisterConfig()
  local AceConfig = LibStub("AceConfig-3.0")
  local AceConfigDialog = LibStub("AceConfigDialog-3.0")
  AceConfig:RegisterOptionsTable("MythicTips", {
    name = "MythicTips",
    type = "group",
    args = {
      display = {
        name = "显示设置",
        type = "group",
        order = 1,
        args = {
          alpha = {
            name = "透明度", desc = "提示框透明度",
            type = "range", order = 1, min = 0.1, max = 1.0, step = 0.1,
            get = function() return db.profile.display.alpha end,
            set = function(_, val)
              db.profile.display.alpha = val
              if mainFrame then mainFrame:SetAlpha(val) end
            end,
          },
          frameWidth = {
            name = "宽度", desc = "提示框宽度",
            type = "range", order = 2, min = 300, max = 1200, step = 10,
            get = function() return db.profile.display.frameWidth end,
            set = function(_, val)
              db.profile.display.frameWidth = val
              if mainFrame and mainFrame:IsShown() then MT:RefreshLayout() end
            end,
          },
          maxHeight = {
            name = "最大高度", desc = "提示框最大高度",
            type = "range", order = 3, min = 200, max = 1200, step = 10,
            get = function() return db.profile.display.maxHeight end,
            set = function(_, val)
              db.profile.display.maxHeight = val
              if mainFrame and mainFrame:IsShown() then MT:RefreshLayout() end
            end,
          },
        },
      },
    },
  })
  AceConfigDialog:AddToBlizOptions("MythicTips", "MythicTips")
end

--- 打开配置面板
function MT:OpenConfig()
  InterfaceOptionsFrame_OpenToCategory("MythicTips")
  InterfaceOptionsFrame_OpenToCategory("MythicTips")
end

--- 计算表元素数量
--- @param t table 要计数的表
--- @return number count
function MT:CountTable(t)
  local count = 0
  for _ in pairs(t) do count = count + 1 end
  return count
end
