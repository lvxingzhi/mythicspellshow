--- MythicTips 样式与常量配置
--- 集中管理UI颜色、尺寸、图标映射等固定不变的配置
--- @author ext.ahs.lvxingz1
local AddonName, MT = ...

MT.Config = {
  --- 尺寸常量
  FRAME_WIDTH = 500,
  FRAME_HEADER_HEIGHT = 28,
  SPELL_LINE_HEIGHT = 24,
  SCROLLBAR_WIDTH = 6,

  --- Tooltip风配色（深灰半透明背景 + 浅灰边框）
  BG_COLOR = { 0.09, 0.09, 0.09, 0.85 },
  BORDER_COLOR = { 0.55, 0.55, 0.55, 0.80 },
  HEADER_COLOR = { 0.12, 0.12, 0.12, 0.90 },
  HEADER_LINE_COLOR = { 0.60, 0.60, 0.60, 0.50 },
  ROW_HOVER_COLOR = { 0.40, 0.60, 0.85, 0.18 },
  TITLE_COLOR = { 1.0, 0.82, 0.0, 1.0 },
  INTERRUPTIBLE_COLOR = { 1.0, 0.30, 0.30, 1.0 },
  TEXT_COLOR = { 0.90, 0.90, 0.90, 1.0 },
  CLOSE_NORMAL_COLOR = { 0.70, 0.70, 0.70, 1.0 },
  CLOSE_HOVER_COLOR = { 1.0, 0.40, 0.40, 1.0 },

  --- tag属性 -> WoW内置图标路径映射
  TAG_ICONS = {
    enrage  = "Interface\\Icons\\Ability_Warrior_Fury",
    magic   = "Interface\\Icons\\Spell_Arcane_Arcane01",
    poison  = "Interface\\Icons\\Spell_Nature_CorrosiveBreath",
    bleed   = "Interface\\Icons\\INV_Weapon_Shortblade_04",
    disease = "Interface\\Icons\\Spell_Shadow_PlagueCloud",
    curse   = "Interface\\Icons\\Spell_Shadow_CurseOfSargeras",
  },

  --- tag属性显示顺序
  TAG_ORDER = { "enrage", "magic", "curse", "disease", "poison", "bleed" },

  --- AceDB默认配置
  DEFAULTS = {
    profile = {
      position = {
        point = "CENTER",
        relPoint = "CENTER",
        x = 0,
        y = 0,
      },
      display = {
        alpha = 0.9,
        frameWidth = 500,
        maxHeight = 800,
      },
    },
  },
}
